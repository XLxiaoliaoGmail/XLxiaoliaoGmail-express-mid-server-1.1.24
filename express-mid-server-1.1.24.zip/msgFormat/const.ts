export const INV_PORT = 8081
export const VIEW_PORT = 8082
export const VIEW_QUERY_KEYNAME = 'viewKey'
export const INV_QUERY_KEYNAME = 'invKey'
export const WEB_SERVER_PORT = 8080